/* ============================================
   RR ENGENHARIA — Main JavaScript v3
   Premium UX with particles, stagger & parallax
   ============================================ */

(function () {
  'use strict';

  // --- HERO PARTICLES ---
  var canvas = document.getElementById('heroParticles');
  if (canvas) {
    var ctx = canvas.getContext('2d');
    var particles = [];
    var particleCount = 60;
    var mouseX = -1000;
    var mouseY = -1000;

    function resizeCanvas() {
      var hero = canvas.parentElement;
      canvas.width = hero.offsetWidth;
      canvas.height = hero.offsetHeight;
    }

    function createParticle() {
      return {
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        size: Math.random() * 2.5 + 0.5,
        speedX: (Math.random() - 0.5) * 0.4,
        speedY: (Math.random() - 0.5) * 0.4,
        opacity: Math.random() * 0.4 + 0.1
      };
    }

    function initParticles() {
      particles = [];
      for (var i = 0; i < particleCount; i++) {
        particles.push(createParticle());
      }
    }

    function drawParticles() {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      for (var i = 0; i < particles.length; i++) {
        var p = particles[i];

        // Move
        p.x += p.speedX;
        p.y += p.speedY;

        // Wrap around
        if (p.x < 0) p.x = canvas.width;
        if (p.x > canvas.width) p.x = 0;
        if (p.y < 0) p.y = canvas.height;
        if (p.y > canvas.height) p.y = 0;

        // Draw particle
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(9, 99, 237, ' + p.opacity + ')';
        ctx.fill();

        // Draw connections to nearby particles
        for (var j = i + 1; j < particles.length; j++) {
          var p2 = particles[j];
          var dx = p.x - p2.x;
          var dy = p.y - p2.y;
          var dist = Math.sqrt(dx * dx + dy * dy);

          if (dist < 150) {
            ctx.beginPath();
            ctx.moveTo(p.x, p.y);
            ctx.lineTo(p2.x, p2.y);
            ctx.strokeStyle = 'rgba(9, 99, 237, ' + (0.06 * (1 - dist / 150)) + ')';
            ctx.lineWidth = 0.5;
            ctx.stroke();
          }
        }

        // Mouse interaction
        var mdx = p.x - mouseX;
        var mdy = p.y - mouseY;
        var mDist = Math.sqrt(mdx * mdx + mdy * mdy);
        if (mDist < 200) {
          ctx.beginPath();
          ctx.moveTo(p.x, p.y);
          ctx.lineTo(mouseX, mouseY);
          ctx.strokeStyle = 'rgba(9, 99, 237, ' + (0.12 * (1 - mDist / 200)) + ')';
          ctx.lineWidth = 0.8;
          ctx.stroke();
        }
      }

      requestAnimationFrame(drawParticles);
    }

    // Only run particles on larger screens
    if (window.innerWidth > 768) {
      resizeCanvas();
      initParticles();
      drawParticles();

      window.addEventListener('resize', function () {
        resizeCanvas();
        initParticles();
      });

      canvas.parentElement.addEventListener('mousemove', function (e) {
        var rect = canvas.getBoundingClientRect();
        mouseX = e.clientX - rect.left;
        mouseY = e.clientY - rect.top;
      });

      canvas.parentElement.addEventListener('mouseleave', function () {
        mouseX = -1000;
        mouseY = -1000;
      });
    }
  }

  // --- MOBILE MENU ---
  var menuToggle = document.getElementById('menuToggle');
  var navList = document.getElementById('navList');

  if (menuToggle && navList) {
    menuToggle.addEventListener('click', function () {
      var isOpen = navList.classList.toggle('open');
      menuToggle.classList.toggle('active');
      menuToggle.setAttribute('aria-expanded', isOpen);
      document.body.style.overflow = isOpen ? 'hidden' : '';
    });

    navList.querySelectorAll('a').forEach(function (link) {
      link.addEventListener('click', function () {
        navList.classList.remove('open');
        menuToggle.classList.remove('active');
        menuToggle.setAttribute('aria-expanded', 'false');
        document.body.style.overflow = '';
      });
    });
  }

  // --- HEADER SCROLL EFFECT ---
  var header = document.getElementById('header');

  function handleHeaderScroll() {
    var scrollY = window.pageYOffset || document.documentElement.scrollTop;
    if (header) {
      if (scrollY > 50) {
        header.classList.add('scrolled');
      } else {
        header.classList.remove('scrolled');
      }
    }
  }

  window.addEventListener('scroll', handleHeaderScroll, { passive: true });

  // --- ACTIVE NAV LINK ---
  function updateActiveNav() {
    var sections = document.querySelectorAll('section[id]');
    var navLinks = document.querySelectorAll('.nav-link');
    var scrollPos = window.pageYOffset + 150;

    sections.forEach(function (section) {
      var top = section.offsetTop;
      var height = section.offsetHeight;
      var id = section.getAttribute('id');

      if (scrollPos >= top && scrollPos < top + height) {
        navLinks.forEach(function (link) {
          link.classList.remove('active');
          if (link.getAttribute('href') === '#' + id) {
            link.classList.add('active');
          }
        });
      }
    });
  }

  window.addEventListener('scroll', updateActiveNav, { passive: true });

  // --- BACK TO TOP ---
  var backToTop = document.getElementById('backToTop');

  function handleBackToTop() {
    if (!backToTop) return;
    if (window.pageYOffset > 400) {
      backToTop.classList.add('visible');
    } else {
      backToTop.classList.remove('visible');
    }
  }

  if (backToTop) {
    backToTop.addEventListener('click', function () {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  window.addEventListener('scroll', handleBackToTop, { passive: true });

  // --- SCROLL REVEAL ANIMATIONS (all types) ---
  function revealOnScroll() {
    var selectors = '.reveal, .reveal-left, .reveal-right, .reveal-scale';
    var reveals = document.querySelectorAll(selectors);
    var windowHeight = window.innerHeight;

    reveals.forEach(function (el) {
      var top = el.getBoundingClientRect().top;
      var revealPoint = windowHeight - 80;

      if (top < revealPoint) {
        el.classList.add('visible');
      }
    });

    // Staggered reveal for grid children
    var staggerContainers = document.querySelectorAll('.reveal-stagger');
    staggerContainers.forEach(function (container) {
      var top = container.getBoundingClientRect().top;
      if (top < windowHeight - 60) {
        var children = container.children;
        for (var i = 0; i < children.length; i++) {
          (function (index) {
            setTimeout(function () {
              children[index].classList.add('visible');
            }, index * 120);
          })(i);
        }
        container.classList.remove('reveal-stagger');
        container.classList.add('reveal-stagger-done');
      }
    });
  }

  window.addEventListener('scroll', revealOnScroll, { passive: true });
  window.addEventListener('load', revealOnScroll);

  // --- STAGGER: give children initial hidden state ---
  document.querySelectorAll('.reveal-stagger').forEach(function (container) {
    var children = container.children;
    for (var i = 0; i < children.length; i++) {
      children[i].style.opacity = '0';
      children[i].style.transform = 'translateY(30px)';
      children[i].style.transition = 'opacity 0.6s ease, transform 0.6s ease';
    }
  });

  // Add visible style for stagger children
  var staggerStyle = document.createElement('style');
  staggerStyle.textContent = '.reveal-stagger-done > .visible, .reveal-stagger > .visible { opacity: 1 !important; transform: translateY(0) !important; }';
  document.head.appendChild(staggerStyle);

  // --- SMOOTH SCROLL FOR ANCHOR LINKS ---
  document.querySelectorAll('a[href^="#"]').forEach(function (anchor) {
    anchor.addEventListener('click', function (e) {
      var targetId = this.getAttribute('href');
      if (targetId === '#') return;

      var target = document.querySelector(targetId);
      if (target) {
        e.preventDefault();
        var headerHeight = header ? header.offsetHeight : 88;
        var targetPos = target.offsetTop - headerHeight;

        window.scrollTo({
          top: targetPos,
          behavior: 'smooth'
        });
      }
    });
  });

  // --- COUNTER ANIMATION FOR STATS ---
  var statNumbers = document.querySelectorAll('.stat-number');
  var statsAnimated = false;

  function animateCounters() {
    if (statsAnimated) return;

    var statsSection = document.querySelector('.hero-stats');
    if (!statsSection) return;

    var rect = statsSection.getBoundingClientRect();
    if (rect.top > window.innerHeight) return;

    statsAnimated = true;

    statNumbers.forEach(function (el) {
      var text = el.textContent.trim();
      var prefix = '';
      var target = 0;

      if (text.startsWith('+')) {
        prefix = '+';
        target = parseInt(text.replace('+', ''), 10);
      } else {
        target = parseInt(text, 10);
      }

      if (isNaN(target)) return;

      var current = 0;
      var increment = Math.ceil(target / 60);
      var duration = 1800;
      var stepTime = duration / (target / increment);

      var timer = setInterval(function () {
        current += increment;
        if (current >= target) {
          current = target;
          clearInterval(timer);
        }
        el.textContent = prefix + current;
      }, stepTime);
    });
  }

  window.addEventListener('scroll', animateCounters, { passive: true });

  // --- INITIAL CHECKS ON LOAD ---
  // Hero entrance animations are handled by CSS @keyframes (cross-browser safe)
  window.addEventListener('load', function () {
    handleHeaderScroll();
    handleBackToTop();
    revealOnScroll();
    animateCounters();
  });

  // Parallax removed — CSS handles hero animations for cross-browser safety

})();
